import numpy as np

# Translation matrices for rotating various faces
rotate_white_yellow_clockwise = np.array([
    [0, -1, 0],
    [1, 0, 0],
    [0, 0, 1]
])

rotate_white_yellow_counterclockwise = np.array([
    [0, 1, 0],
    [-1, 0, 0],
    [0, 0, 1]
])

rotate_green_blue_clockwise = np.array([
    [1, 0, 0],
    [0, 0, -1],
    [0, 1, 0]
])

rotate_green_blue_counterclockwise = np.array([
    [1, 0, 0],
    [0, 0, 1],
    [0, -1, 0]
])

rotate_red_orange_clockwise = np.array([
    [0, 0, 1],
    [0, 1, 0],
    [-1, 0, 0]
])

rotate_red_orange_counterclockwise = np.array([
    [0, 0, -1],
    [0, 1, 0],
    [1, 0 ,0]
])