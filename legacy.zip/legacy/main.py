import numpy as np
import legacy.translations as translations,legacy.orientations as orientations

# Ternary 3D coordinate system: core is 0,0,0
# White face is 0,0,1
# Yellow face is 0,0,-1
# Blue face is 1,0,0
# Green face is -1,0,0
# Red face is 0,1,0
# Orange face is 0,-1,0


# Used for defining orientations
WHITE = 1 # z
YELLOW = -1 # -z
BLUE = 2 # x
GREEN = -2 # -x
RED = 3 # y
ORANGE = -3 # -y

class Corner():
    def __init__(self, coords, colours, orientation):
        self.coords = coords # coordinates of the vertex at the current moment
        self.colours = colours
        self.orientation = orientation # coordinates of the face toward which the (sometimes imaginary) white side of this piece is facing

class CubeState():
    def __init__(self, pieces=None):
        if pieces==None:
            self.corners = []
            for x in [-1,1]:
                for y in [-1,1]:
                    for z in [-1,1]:
                        corner_colours = [
                            BLUE if x==1 else GREEN ,
                            RED if y==1 else ORANGE ,
                            WHITE if z==1 else YELLOW
                        ]
                        self.corners.append( Corner(
                            np.array([x,y,z]) ,
                            corner_colours ,
                            np.array([0,0,1]) # assume orientation is correct when initialising a cubestate
                        ))

    # Turning a face 'clockwise' means clockwise WHILE LOOKING AT RED, WHITE, or BLUE ('positive faces')
    def rotate_white_clockwise(self):
        white_face_corners = filter( lambda c : c.coords[2] == 1 , self.corners )

        for corner_affected in white_face_corners:
            corner_affected.coords = translations.rotate_white_yellow_clockwise.dot( corner_affected.coords )
            corner_affected.orientation = orientations.rotate_white_yellow.dot( corner_affected.orientation )
    
    def rotate_white_counterclockwise(self):
        white_face_corners = filter( lambda c : c.coords[2] == 1 , self.corners )

        for corner_affected in white_face_corners:
            corner_affected.coords = translations.rotate_white_yellow_counterclockwise.dot( corner_affected.coords )
            corner_affected.orientation = orientations.rotate_white_yellow.dot( corner_affected.orientation )
    
    def rotate_yellow_clockwise(self):
        yellow_face_corners = filter( lambda c : c.coords[2] == -1 , self.corners )

        for corner_affected in yellow_face_corners:
            corner_affected.coords = translations.rotate_white_yellow_clockwise.dot( corner_affected.coords )
            corner_affected.orientation = orientations.rotate_white_yellow.dot( corner_affected.orientation )
    
    def rotate_yellow_counterclockwise(self):
        yellow_face_corners = filter( lambda c : c.coords[2] == -1 , self.corners )

        for corner_affected in yellow_face_corners:
            corner_affected.coords = translations.rotate_white_yellow_counterclockwise.dot( corner_affected.coords )
            corner_affected.orientation = orientations.rotate_white_yellow.dot( corner_affected.orientation )
    
    def rotate_blue_clockwise(self):
        blue_face_corners = filter( lambda c : c.coords[0] == 1 , self.corners )

        for corner_affected in blue_face_corners:
            corner_affected.coords = translations.rotate_green_blue_clockwise.dot( corner_affected.coords )
            corner_affected.orientation = orientations.rotate_green_blue_clockwise.dot( corner_affected.orientation )

    def rotate_blue_counterclockwise(self):
        blue_face_corners = filter( lambda c : c.coords[0] == 1 , self.corners )

        for corner_affected in blue_face_corners:
            corner_affected.coords = translations.rotate_green_blue_counterclockwise.dot( corner_affected.coords )
            corner_affected.orientation = orientations.rotate_green_blue_counterclockwise.dot( corner_affected.orientation )

    def rotate_green_clockwise(self):
        green_face_corners = filter( lambda c : c.coords[0] == -1 , self.corners )

        for corner_affected in green_face_corners:
            corner_affected.coords = translations.rotate_green_blue_clockwise.dot( corner_affected.coords )
            corner_affected.orientation = orientations.rotate_green_blue_clockwise.dot( corner_affected.orientation )

    def rotate_green_counterclockwise(self):
        green_face_corners = filter( lambda c : c.coords[0] == -1 , self.corners )

        for corner_affected in green_face_corners:
            corner_affected.coords = translations.rotate_green_blue_counterclockwise.dot( corner_affected.coords )
            corner_affected.orientation = orientations.rotate_green_blue_counterclockwise.dot( corner_affected.orientation )

    def rotate_red_clockwise(self):
        red_face_corners = filter( lambda c : c.coords[1] == 1 , self.corners )

        for corner_affected in red_face_corners:
            corner_affected.coords = translations.rotate_red_orange_clockwise.dot( corner_affected.coords )
            corner_affected.orientation = orientations.rotate_red_orange_clockwise.dot( corner_affected.orientation )
        
    def rotate_red_counterclockwise(self):
        red_face_corners = filter( lambda c : c.coords[1] == 1 , self.corners )

        for corner_affected in red_face_corners:
            corner_affected.coords = translations.rotate_red_orange_counterclockwise.dot( corner_affected.coords )
            corner_affected.orientation = orientations.rotate_red_orange_counterclockwise.dot( corner_affected.orientation )
        
    def rotate_orange_clockwise(self):
        orange_face_corners = filter( lambda c : c.coords[1] == -1 , self.corners )

        for corner_affected in orange_face_corners:
            corner_affected.coords = translations.rotate_red_orange_clockwise.dot( corner_affected.coords )
            corner_affected.orientation = orientations.rotate_red_orange_clockwise.dot( corner_affected.orientation )
        
    def rotate_orange_counterclockwise(self):
        orange_face_corners = filter( lambda c : c.coords[1] == -1 , self.corners )

        for corner_affected in orange_face_corners:
            corner_affected.coords = translations.rotate_red_orange_counterclockwise.dot( corner_affected.coords )
            corner_affected.orientation = orientations.rotate_red_orange_counterclockwise.dot( corner_affected.orientation )
    
    def output(self):
        for corner in self.corners:
            print(corner.coords,end=" \t ")
            print(corner.colours,end=" \t ")
            print(corner.orientation)

myCube = CubeState()
myCube.output()
